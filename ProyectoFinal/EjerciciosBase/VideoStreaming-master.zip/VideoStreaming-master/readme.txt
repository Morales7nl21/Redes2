running server:
$java Server arg1
arg1=port no used by server

running client:
$java Client arg1 arg2 arg3 arg4
arg1=IP adress of server - localhost
arg2=port no of server
arg3=port no for client RTP data
arg4=video selection//always give this argument as '01' since only 01 video is being included with code


*** make: Nothing to be done for 'default' ***

The above message indicates that all the files are compiled already.


link to live demo video

https://www.youtube.com/watch?v=DNM-b5J5j8k
