
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author LENOVO 720
 */
public class comunicaAdelante {

    public hilo hilo1;
    public hilo siguiente;
    public int idx_empiezo;
    public int total;
    
    public comunicaAdelante() {
        
    }

    public comunicaAdelante(hilo hilo1, hilo siguiente) {
        this.hilo1 = hilo1;
        this.siguiente = siguiente;
    }

    public int estaArchivo(hilo h1, hilo h2) {
        int flag = 0;
        return flag;
    }

    public int estaArchivoGeneral(hilo h1, InterfazHilo ih) {

        int flag = -1;

        hilo tmp = h1.siguiente;
        InterfazHilo tmpI = ih.getIsiguiente();
        for (int i = 0; i < total; i++) {
            flag = h1.siguiente.estaArchivo(h1.busqueda, h1.siguiente.getRuta());
            if (flag != 1) {
                h1.siguiente = h1.siguiente.siguiente;
            }
        }

        h1.siguiente = tmp;
        ih.setIsiguiente(tmpI);
        return flag;

    }

    public void alteraInterfaz(String hiloB, InterfazHilo ih, String busqueda, String hilosig, int i) {
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        Runnable task1;
        task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
        task1 = () -> ih.textArea.append("[+] La busqueda de: " + hiloB + " " + busqueda);
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);

        task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);

        task1 = () -> ih.textArea.append("[-]" + hilosig + " no se encontró aquí");
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
    }

    public void alteraInterfazInversa(String hiloB,String encontro,  InterfazHilo ih,String hant, String busqueda, String Path, int i) {
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        Runnable task1;
        task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
        task1 = () -> ih.textArea.append("[+] La busqueda de: " + hiloB + " " + busqueda);
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
         task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);

        task1 = () -> ih.textArea.append("[+] se encontró en el hilo: " + encontro + " con la path: " + Path);
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
        

        task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);

        task1 = () -> ih.textArea.append("[+]" + hant + " ahora le  pasare  la respuesta al hilo anterior");
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);
        task1 = () -> ih.textArea.append(System.getProperty("line.separator"));
        service.scheduleAtFixedRate(task1, 2 * i + 1, 200, TimeUnit.SECONDS);

    }

    public int idxEncontrado(hilo h, String busqueda) {

        int idx = 0;
        int flag;
        hilo tmp = h.siguiente;

        for (int i = 0; i < total; i++) {
            flag = h.siguiente.estaArchivo(h.busqueda, h.siguiente.getRuta());
            if (flag != 1) {
                h.siguiente = h.siguiente.siguiente;
            }
            if (flag == 1) {
                idx = h.siguiente.getID();
            }
        }
        h.siguiente = tmp;
        return idx;
    }

}
