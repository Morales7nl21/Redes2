
import java.io.File;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author LENOVO 720
 */
public class hilo extends Thread {

    private String ruta;
    private int id;
    public hilo siguiente;
    public hilo anterior;
    public int estado = 0;
    public int nothing;
    public String ruta_externa;
    public InterfazHilo Ih;
    public String busqueda;
    InterfazHilo interfaces = new InterfazHilo(this);
    public int total;
    public void setSiguiente(hilo siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
    PipedOutputStream pout;// = new PipedOutputStream();
    PipedInputStream pit;

    public hilo(String ruta, int id ) {
        this.ruta = ruta;
        this.id = id;
    }

    public hilo(String ruta, int id, hilo ant, hilo sig) {
        this.ruta = ruta;
        this.id = id;
        this.siguiente = sig;
        this.anterior = ant;
    }

    @Override
    public void run() {
        
        interfaces.setIsiguiente(siguiente.interfaces);
        interfaces.setIanterior(anterior.interfaces);
        interfaces.hant = anterior.getName();
        interfaces.nombreHiloPre.setText(anterior.getName());
        interfaces.nombreHiloSig.setText(siguiente.getName());
        interfaces.nombreHiloForm.setText(this.getName());
        interfaces.hsig = siguiente.getName();
        interfaces.idx = id;
      
        interfaces.setVisible(true);
    
    }
    public int estaArchivo(String archivo, String path){
        
        File carpeta = new File(path);
        String[] listado = carpeta.list();
        int bandera_busqueda = 0;
        if (listado == null || listado.length == 0) {
            bandera_busqueda = -1;
        } else {
            for (int i = 0; i < listado.length; i++) {
                if (listado[i].equals(archivo)) {
                    bandera_busqueda = 1;
                } else if(bandera_busqueda != 1){
                    bandera_busqueda = 2;
                }
            }
        }
        return bandera_busqueda;
        
    }
    public String rutaArchivo(hilo h, String archivo){
    if(estaArchivo(archivo,h.getRuta()) != 1){
        return ("[-] "+h.getName() + "No está aqui-");
    }else{
        return ("[+] "+ h.getName() +" Dirección "+ h.getRuta());
    }
    
    }

    public String getRuta() {
        return ruta;
    }

    public int getID() {
        return id;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public void setId(int id) {
        this.id = id;
    }

}
