/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO 720
 */
import javax.swing.JOptionPane;

public class examen {

    public static void main(String[] args) {
        int entradaUsuario;
        do {
            entradaUsuario = Integer.valueOf(JOptionPane.showInputDialog("Introduzca  el número de hilos a usar:"));
        } while (entradaUsuario < 0 || entradaUsuario > 10);
        hilo arr[] = new hilo[entradaUsuario];

        String paths[] = {"C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C1",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C2",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C3",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C4",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C5",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C6",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C7",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C8",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C9",
            "C://Users//LENOVO 720//Desktop//IPN Documents//6toSemestre//Redes//examen//10Carpetas//C10"};
       
        for (int i = 0; i < entradaUsuario; i++) {
            if (i == 0) {
                arr[i] = new hilo(paths[i], i);
            } else if (i == (entradaUsuario - 1)) {
                arr[i] = new hilo(paths[i], i, arr[i - 1], arr[i - entradaUsuario + 1]);
            } else {

                arr[i] = new hilo(paths[i], i, arr[i - 1], arr[i + 1]);
            }

        }
        for (int i = 0; i < entradaUsuario; i++) {
            if (i == 0) {
                arr[i].siguiente = arr[i + 1];
                arr[i].anterior = arr[entradaUsuario - 1];
                arr[i].total=entradaUsuario-1;

            } else if (i == (entradaUsuario - 1)) {
                arr[i].anterior = arr[i - 1];
                arr[i].siguiente = arr[0];
                arr[i].total=entradaUsuario-1;
            } else if (i > 0 && i < entradaUsuario - 1) {

                arr[i].siguiente = arr[i + 1];
                arr[i].anterior = arr[i - 1];
                arr[i].total=entradaUsuario-1;
             
            }
        }
        //CORREMOS LOS HILOS 
        for (int i = 0; i < entradaUsuario; i++) {
            Thread arr_hilos = new Thread(arr[i]);
            arr_hilos.start();
        }
         
    }
}
