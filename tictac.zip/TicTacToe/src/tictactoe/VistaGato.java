package tictactoe;

import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class VistaGato extends JFrame {

    public VistaGato interfazH1;
    public VistaGato interfazOponente;

    public JButton[][] casilla = new JButton[3][3]; // El tablero VISUAL
    public char[][] tablero = new char[3][3];       // El tablero en MEMORIA
    private hilo jugador1h, jugador2h;
    public JButton botonElegido;
    public hilo h;
    public int jugador = 1;   // Variable que guarda el número de jugador que hace la jugada 
    private int contador = 0;  // Contador de jugadas
    public boolean cerrar = false;
    public boolean control = true;
    public int mod2 = 2;

    public VistaGato(hilo h) // Constructor
    {

        //this.setTitle("TIC TAC TOE ");
        this.h = h;
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setBounds(150, 50, 620, 665);
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("gatito.jpg"));
        initComponents();
    }

    public void initComponents() {
        // Diseña menú
        JMenuBar barraMenus = new JMenuBar();
        JMenu archivo = new JMenu("Archivo");
        JMenuItem reset = new JMenuItem("Restituir");
        JMenuItem salir = new JMenuItem("Salir");
        this.setJMenuBar(barraMenus);
        barraMenus.add(archivo);
        archivo.add(reset);
        archivo.add(new JSeparator());
        archivo.add(salir);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                casilla[i][j] = new JButton(i + "-" + j); // Coloca sobre la cara del evento el texto 'i-j'               
                casilla[i][j].setBorder(BorderFactory.createRaisedBevelBorder());
               
            }
        }
        resetTablero();

        // Coordenadas
        casilla[0][0].setBounds(0, 0, 198, 198);
        casilla[0][1].setBounds(200, 0, 198, 198);
        casilla[0][2].setBounds(400, 0, 198, 198);
        casilla[1][0].setBounds(0, 200, 198, 198);
        casilla[1][1].setBounds(200, 200, 198, 198);
        casilla[1][2].setBounds(400, 200, 198, 198);
        casilla[2][0].setBounds(0, 400, 198, 198);
        casilla[2][1].setBounds(200, 400, 198, 198);
        casilla[2][2].setBounds(400, 400, 198, 198);

        // Componentes auxiliares
        // Posiciones de los componentes
        this.setLayout(null); // El programador indica coordenadas y tamaño

        // Coloca componentes
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                this.add(casilla[i][j]);
            }
        }

        // Gestión de eventos (Agrega los LISTENERS)
        // Agrega Listener al JMenuItem 'salir'
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salir(evt);
            }
        });

        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetTablero();
            }
        });

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                casilla[i][j].addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jugar(evt);  // Delega la tarea al método 'jugar' pasándole referencia a 'evt'
                    }
                });
            }
        }

        // Agrega Listener al boton 'X' del JFrame
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cerrarFrame();
            }
        });
    }

    // Métodos delegados de los Listeners
    public void salir(java.awt.event.ActionEvent evt) {
        cerrar = true;
        this.dispose();
        this.setVisible(false);

    }

    public void cerrarFrame() {
        int respuesta = JOptionPane.showConfirmDialog(this, "Desea salir?", "Aviso", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            //System.exit(0);
            interfazOponente.dispose();
            interfazOponente.setVisible(false);
            this.dispose();           
            this.setVisible(false);
        }
    }

    // Este método se invoca desde el Listener de todos los botones del tablero
    // La referencia evt contiene información sobre el objeto que generó el evento
    public void jugar(java.awt.event.ActionEvent evt) {
        contador++; // Incrementa el contador de jugadas

        String actionCommand = evt.getActionCommand();  // Recupera el texto de la cara del botón que generó el evento

        int i = actionCommand.charAt(0) - 48; // Obtiene el primer caracter del texto, como ASCII
        int j = actionCommand.charAt(2) - 48; // Obtiene el tercer caracter del texto, como ASCII
        //JOptionPane.showMessageDialog(null, "i = " + String.valueOf(i) + "j = " + String.valueOf(j));
       // JOptionPane.showMessageDialog(this, "Jugador:" + String.valueOf(jugador) + "  name h: " + String.valueOf(h.getName()) + "mod = " + String.valueOf(mod2));
        if (h.p==1 && mod2 == 2) {
            botonElegido = (JButton) evt.getSource(); // Obtiene referencia al objeto que generó el evento
            //interfazOponente.jugador=2;
            //if (control) {

            //JOptionPane.showMessageDialog(this, "Jugador:" + String.valueOf(jugador) + "  name h: " + String.valueOf(h.getName()));

            try {
                for (int k = 0; k < 3; k++) {
                    for (int l = 0; l < 3; l++) {
                        if (botonElegido == casilla[k][l]) {
                            //JOptionPane.showMessageDialog(null, "Boton " + String.valueOf(k) +" ,"+ String.valueOf(l));
                            interfazOponente.casilla[k][l].setEnabled(false);
                            interfazOponente.contador = contador;
                            if (jugador == 1) {
                                interfazOponente.casilla[k][l].setIcon(new ImageIcon("x.jpg"));
                                interfazOponente.tablero[i][j] = 'X';
                            } else {
                                interfazOponente.casilla[k][l].setIcon(new ImageIcon("o.jpg"));
                                interfazOponente.tablero[i][j] = 'O';
                            }
                            if (interfazOponente.revisaTablero(tablero[i][j])) {
                                JOptionPane.showMessageDialog(interfazOponente, "Ha ganado el jugador: " + jugador, "Aviso", JOptionPane.ERROR_MESSAGE);
                                interfazOponente.cerrarFrame();
                                if (!interfazOponente.cerrar) {
                                    interfazOponente.resetTablero();
                                }
                            }

                            // Revisa si ya se completado el tablero
                            if (contador == 9) {
                                JOptionPane.showMessageDialog(interfazOponente, "Se ha alcanzado el maximo de jugadas", "Aviso", JOptionPane.ERROR_MESSAGE);
                                interfazOponente.cerrarFrame();
                                if (!interfazOponente.cerrar) {
                                    interfazOponente.resetTablero();
                                }

                            }
                            interfazOponente.control = true;

                        }

                    }

                }

                //}
                interfazOponente.botonElegido = (JButton) evt.getSource();
                interfazOponente.botonElegido.setEnabled(false);
                botonElegido.setEnabled(false);
                if (jugador == 1) {
                    botonElegido.setIcon(new ImageIcon("x.jpg"));

                    tablero[i][j] = 'X';
                } else {
                    botonElegido.setIcon(new ImageIcon("o.jpg"));
                    interfazOponente.botonElegido.setIcon(new ImageIcon("o.jpg"));
                    tablero[i][j] = 'O';
                }

                // Revisa tablero para ver si el jugador actual ha ganado
                if (revisaTablero(tablero[i][j])) {
                    JOptionPane.showMessageDialog(this, "Ha ganado el jugador: " + jugador, "Aviso", JOptionPane.ERROR_MESSAGE);
                    cerrarFrame();
                    if (!cerrar) {
                        resetTablero();
                    }
                }

                // Revisa si ya se completado el tablero
                if (contador == 9) {
                    JOptionPane.showMessageDialog(this, "Se ha alcanzado el maximo de jugadas", "Aviso", JOptionPane.ERROR_MESSAGE);
                    resetTablero();
                }
                interfazOponente.mod2=1;
                jugador = 2;
                mod2 = 1;
            } catch (Exception ex) {
                Logger.getLogger(VistaGato.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                //h.notify();
                mod2 = 1;
                interfazOponente.mod2=1;
                //h.jugadorContrario.p = 2;
                if (jugador == 2) {
                    jugador = 1;
                } else {
                    jugador = 2;

                }
               
            }
        }

        if (h.p==2  && mod2 == 1) {

            botonElegido = (JButton) evt.getSource(); // Obtiene referencia al objeto que generó el evento
            
            try {
                for (int k = 0; k < 3; k++) {
                    for (int l = 0; l < 3; l++) {
                        if (botonElegido == casilla[k][l]) {
                            //JOptionPane.showMessageDialog(null, "Boton " + String.valueOf(k) +" ,"+ String.valueOf(l));
                            interfazOponente.casilla[k][l].setEnabled(false);
                            interfazOponente.contador = contador;
                            if (jugador == 1) {
                                interfazOponente.casilla[k][l].setIcon(new ImageIcon("x.jpg"));
                                interfazOponente.tablero[i][j] = 'X';
                            } else {
                                interfazOponente.casilla[k][l].setIcon(new ImageIcon("o.jpg"));
                                interfazOponente.tablero[i][j] = 'O';
                            }
                            if (interfazOponente.revisaTablero(tablero[i][j])) {
                                JOptionPane.showMessageDialog(interfazOponente, "Ha ganado el jugador: " + jugador, "Aviso", JOptionPane.ERROR_MESSAGE);
                                interfazOponente.cerrarFrame();
                                if (!interfazOponente.cerrar) {
                                    interfazOponente.resetTablero();
                                    resetTablero();
                                }
                            }

                            // Revisa si ya se completado el tablero
                            if (contador == 9) {
                                JOptionPane.showMessageDialog(interfazOponente, "Se ha alcanzado el maximo de jugadas", "Aviso", JOptionPane.ERROR_MESSAGE);
                                interfazOponente.cerrarFrame();
                                if (!interfazOponente.cerrar) {
                                    interfazOponente.resetTablero();
                                    resetTablero();
                                }

                            }
                            interfazOponente.control = true;

                        }

                    }

                }

                //}
                interfazOponente.botonElegido = (JButton) evt.getSource();
                interfazOponente.botonElegido.setEnabled(false);
                botonElegido.setEnabled(false);
                if (jugador == 1) {
                    botonElegido.setIcon(new ImageIcon("x.jpg"));

                    tablero[i][j] = 'X';
                } else {
                    botonElegido.setIcon(new ImageIcon("o.jpg"));
                    interfazOponente.botonElegido.setIcon(new ImageIcon("o.jpg"));
                    tablero[i][j] = 'O';
                }

                // Revisa tablero para ver si el jugador actual ha ganado
                if (revisaTablero(tablero[i][j])) {
                    JOptionPane.showMessageDialog(this, "Ha ganado el jugador: " + jugador, "Aviso", JOptionPane.ERROR_MESSAGE);
                    cerrarFrame();
                    if (!cerrar) {
                        resetTablero();
                        interfazOponente.resetTablero();
                    }
                }

                // Revisa si ya se completado el tablero
                if (contador == 9) {
                    JOptionPane.showMessageDialog(this, "Se ha alcanzado el maximo de jugadas", "Aviso", JOptionPane.ERROR_MESSAGE);
                    interfazOponente.resetTablero();
                    resetTablero();
                }
                mod2 = 2;
                interfazOponente.mod2=2;
                //h.jugadorContrario.p = 1;
                jugador = 1;
            } catch (Exception ex) {
                Logger.getLogger(VistaGato.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                //h.jugadorContrario.p = 1;
                //h.notify();
                mod2 = 2;
              
                interfazOponente.mod2=2;
          
                if (jugador == 1) {
                    jugador = 2;
                } else {
                    jugador = 1;

                }
            }

        }
        
    }

    /* 
        Método para verificar si un jugador ha ganado, utilizando el 
        símbolo de la última jugada, revisa si ese símbolo ha completado
        una línea de 3 (horizontal, vertical o diagonal)
     */
    public boolean revisaTablero(char letra) {
        boolean ganador = false;

        //Esquinas
        if (tablero[0][0] == 'X' && tablero[1][1] == 'X' && tablero[2][2] == 'X' || (tablero[0][0] == 'O' && tablero[1][1] == 'O' && tablero[2][2] == 'O')) {
            ganador = true;

        } else if (tablero[2][0] == 'X' && tablero[1][1] == 'X' && tablero[0][2] == 'X' || (tablero[2][0] == 'O' && tablero[1][1] == 'O' && tablero[0][2] == 'O')) {
            ganador = true;
        } //Fin Esquinas
        // INICIO DE FILAS //
        //Fila 1 
        else if (tablero[0][0] == 'X' && tablero[0][1] == 'X' && tablero[0][2] == 'X' || (tablero[0][0] == 'O' && tablero[0][1] == 'O' && tablero[0][2] == 'O')) {
            ganador = true;
        } //Fila 2
        else if (tablero[1][0] == 'X' && tablero[1][1] == 'X' && tablero[1][2] == 'X' || (tablero[1][0] == 'O' && tablero[1][1] == 'O' && tablero[1][2] == 'O')) {
            ganador = true;
        } //Fila 3
        else if (tablero[2][0] == 'X' && tablero[2][1] == 'X' && tablero[2][2] == 'X' || (tablero[2][0] == 'O' && tablero[2][1] == 'O' && tablero[2][2] == 'O')) {
            ganador = true;
        } //Fin filas
        // INICIO DE COLUMNAS //
        //Columna 1
        else if (tablero[0][0] == 'X' && tablero[1][0] == 'X' && tablero[2][0] == 'X' || (tablero[0][0] == 'O' && tablero[1][0] == 'O' && tablero[2][0] == 'O')) {
            ganador = true;
        } //Columna 2
        else if (tablero[0][1] == 'X' && tablero[1][1] == 'X' && tablero[2][1] == 'X' || (tablero[0][1] == 'O' && tablero[1][1] == 'O' && tablero[2][1] == 'O')) {
            ganador = true;
        } //Fila 3
        else if (tablero[0][2] == 'X' && tablero[1][2] == 'X' && tablero[2][2] == 'X' || (tablero[0][2] == 'O' && tablero[1][2] == 'O' && tablero[2][2] == 'O')) {
            ganador = true;
        }
        //Fin COLUMNAS

        return ganador;

    }

    // Método para que establece el estado inicial del tablero visual e interno
    public void resetTablero() {
        //interfazOponente.resetTablero();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                // Establece la imagen en la casilla i,j tomando la imagen "img-i-j.png"
                casilla[i][j].setIcon(new ImageIcon("img-" + i + "-" + j + ".png"));
                tablero[i][j] = ' ';
                casilla[i][j].setEnabled(true);
                

            }
        }
        contador = 0; // Reinicia el contador de jugadas
    }

    public VistaGato getInterfazH1() {
        return interfazH1;
    }

    public void setInterfazH1(VistaGato interfazH1) {
        this.interfazH1 = interfazH1;
    }

    public VistaGato getInterfazOponente() {
        return interfazOponente;
    }

    public void setInterfazOponente(VistaGato interfazH2) {
        this.interfazOponente = interfazH2;
    }

    public hilo getJugador1h() {
        return jugador1h;
    }

    public void setJugador1h(hilo jugador1) {
        this.jugador1h = jugador1;
    }

    public hilo getJugador2h() {
        return jugador2h;
    }

    public void setJugador2h(hilo jugador2) {
        this.jugador2h = jugador2;
    }
// Fin de la clase
}
