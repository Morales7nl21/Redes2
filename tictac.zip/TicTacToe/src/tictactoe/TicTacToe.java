
package tictactoe;

import javax.swing.JOptionPane;

public class TicTacToe {

    public static void main(String[] args) {
        int entradaUsuario;
        
       
        do {
          entradaUsuario = Integer.valueOf(JOptionPane.showInputDialog("Introduzca  el número de juegos de gato"));
        } while (entradaUsuario < 0 || entradaUsuario > 10);
        
        hilo arr[] = new hilo[entradaUsuario];
        hilo arr2[] = new hilo[entradaUsuario];
      
        int p = 1;
        int p2 = 2;
        for (int i = 0; i < (entradaUsuario); i++) {
            
            arr[i] = new hilo(i,p);   
            arr2[i] = new hilo(i,p2);                        
        }
        for (int i = 0; i < (entradaUsuario); i++) {          
                arr[i].setJugadorContrario(arr2[i]);
                arr2[i].setJugadorContrario(arr[i]);
                           
        }
        for (int i = 0; i < (entradaUsuario); i++) {       
                arr[i].start();
                arr2[i].start();            
        }
        
    }    
}
