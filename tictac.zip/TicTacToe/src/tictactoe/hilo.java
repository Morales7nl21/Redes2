/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO 720
 */
public class hilo extends Thread{
    public hilo jugadorContrario;
    public hilo esteHilo = this;
    public VistaGato tableroGato = new VistaGato(this);
    public int p = 0;
    public int id = 0;
    
   
    public hilo(int id, int p) { 
        this.id = id;
        this.p = p;
    }
    public hilo(hilo jugadorContrario, int id) {
        this.jugadorContrario = jugadorContrario;
       // tableroGato =  new VistaGato(jugadorContrario.esteHilo);
        this.id = id;
    }
   
    @Override
     public void run() {
        tableroGato.setInterfazOponente(jugadorContrario.tableroGato);
        tableroGato.setTitle(this.getName() + "vs" + jugadorContrario.getName() + "\t PESTAÑA HILO: " + this.getName());
        //tableroGato.setJugador2h(jugadorContrario);
        tableroGato.jugador = 1;
        jugadorContrario.tableroGato.jugador=2;
        //JOptionPane.showMessageDialog(null, this.getName() +" "+ jugadorContrario.getName());
        tableroGato.setVisible(true);  
    }
    public synchronized void sincroniza(Object VistaGato){
        VistaGato.notify();
    }
    public synchronized void espera() throws InterruptedException{
        wait();
        
    }
    public hilo getJugadorContrario() {
        return jugadorContrario;
    }

    public void setJugadorContrario(hilo jugadorContrario) {
        this.jugadorContrario = jugadorContrario;
    }
    
    
}
